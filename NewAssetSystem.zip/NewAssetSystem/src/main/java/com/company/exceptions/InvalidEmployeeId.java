package com.company.exceptions;

public class InvalidEmployeeId extends Exception{
	private static final long serialVersionUID = 1L;
	public InvalidEmployeeId(String msg) {
		super(msg);
	}
}
