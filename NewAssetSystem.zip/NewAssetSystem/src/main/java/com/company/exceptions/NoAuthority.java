package com.company.exceptions;

public class NoAuthority extends Exception {
	public NoAuthority(String str) {
		super(str);
	}
	

}
